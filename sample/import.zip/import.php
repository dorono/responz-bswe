<?php

defined( 'ABSPATH' ) or die;

$GLOBALS['processed_terms'] = array();
$GLOBALS['processed_posts'] = array();

require_once ABSPATH . 'wp-admin/includes/post.php';
require_once ABSPATH . 'wp-admin/includes/taxonomy.php';
require_once ABSPATH . 'wp-admin/includes/image.php';

/**
 * Add an Import Action, this data is stored for processing after import is done.
 *
 * Each action is sent as an Ajax request and is handled by themify-ajax.php file
 */ 
function themify_add_import_action( $action = '', $data = array() ) {
	global $import_actions;

	if ( ! isset( $import_actions[ $action ] ) ) {
		$import_actions[ $action ] = array();
	}

	$import_actions[ $action ][] = $data;
}

function themify_import_post( $post ) {
	global $processed_posts, $processed_terms;

	if ( ! post_type_exists( $post['post_type'] ) ) {
		return;
	}

	/* Menu items don't have reliable post_title, skip the post_exists check */
	if( $post['post_type'] !== 'nav_menu_item' ) {
		$post_exists = post_exists( $post['post_title'], '', $post['post_date'] );
		if ( $post_exists && get_post_type( $post_exists ) == $post['post_type'] ) {
			$processed_posts[ intval( $post['ID'] ) ] = intval( $post_exists );
			return;
		}
	}

	if( $post['post_type'] == 'nav_menu_item' ) {
		if( ! isset( $post['tax_input']['nav_menu'] ) || ! term_exists( $post['tax_input']['nav_menu'], 'nav_menu' ) ) {
			return;
		}
		$_menu_item_type = $post['meta_input']['_menu_item_type'];
		$_menu_item_object_id = $post['meta_input']['_menu_item_object_id'];

		if ( 'taxonomy' == $_menu_item_type && isset( $processed_terms[ intval( $_menu_item_object_id ) ] ) ) {
			$post['meta_input']['_menu_item_object_id'] = $processed_terms[ intval( $_menu_item_object_id ) ];
		} else if ( 'post_type' == $_menu_item_type && isset( $processed_posts[ intval( $_menu_item_object_id ) ] ) ) {
			$post['meta_input']['_menu_item_object_id'] = $processed_posts[ intval( $_menu_item_object_id ) ];
		} else if ( 'custom' != $_menu_item_type ) {
			// associated object is missing or not imported yet, we'll retry later
			// $missing_menu_items[] = $item;
			return;
		}
	}

	$post_parent = ( $post['post_type'] == 'nav_menu_item' ) ? $post['meta_input']['_menu_item_menu_item_parent'] : (int) $post['post_parent'];
	$post['post_parent'] = 0;
	if ( $post_parent ) {
		// if we already know the parent, map it to the new local ID
		if ( isset( $processed_posts[ $post_parent ] ) ) {
			if( $post['post_type'] == 'nav_menu_item' ) {
				$post['meta_input']['_menu_item_menu_item_parent'] = $processed_posts[ $post_parent ];
			} else {
				$post['post_parent'] = $processed_posts[ $post_parent ];
			}
		}
	}

	/**
	 * for hierarchical taxonomies, IDs must be used so wp_set_post_terms can function properly
	 * convert term slugs to IDs for hierarchical taxonomies
	 */
	if( ! empty( $post['tax_input'] ) ) {
		foreach( $post['tax_input'] as $tax => $terms ) {
			if( is_taxonomy_hierarchical( $tax ) ) {
				$terms = explode( ', ', $terms );
				$post['tax_input'][ $tax ] = array_map( 'themify_get_term_id_by_slug', $terms, array_fill( 0, count( $terms ), $tax ) );
			}
		}
	}

	$post['post_author'] = (int) get_current_user_id();
	$post['post_status'] = 'publish';

	$old_id = $post['ID'];

	unset( $post['ID'] );
	$post_id = wp_insert_post( $post, true );
	if( is_wp_error( $post_id ) ) {
		return false;
	} else {
		$processed_posts[ $old_id ] = $post_id;

		return $post_id;
	}
}

function themify_get_placeholder_image() {
	static $placeholder_image = null;

	if( $placeholder_image == null ) {
		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		WP_Filesystem();
		global $wp_filesystem;
		$upload = wp_upload_bits( $post['post_name'] . '.jpg', null, $wp_filesystem->get_contents( THEMIFY_DIR . '/img/image-placeholder.jpg' ) );

		if ( $info = wp_check_filetype( $upload['file'] ) )
			$post['post_mime_type'] = $info['type'];
		else
			return new WP_Error( 'attachment_processing_error', __( 'Invalid file type', 'themify' ) );

		$post['guid'] = $upload['url'];
		$post_id = wp_insert_attachment( $post, $upload['file'] );
		wp_update_attachment_metadata( $post_id, wp_generate_attachment_metadata( $post_id, $upload['file'] ) );

		$placeholder_image = $post_id;
	}

	return $placeholder_image;
}

function themify_import_term( $term ) {
	global $processed_terms;

	if( $term_id = term_exists( $term['slug'], $term['taxonomy'] ) ) {
		if ( is_array( $term_id ) ) $term_id = $term_id['term_id'];
		if ( isset( $term['term_id'] ) )
			$processed_terms[ intval( $term['term_id'] ) ] = (int) $term_id;
		return (int) $term_id;
	}

	if ( empty( $term['parent'] ) ) {
		$parent = 0;
	} else {
		$parent = term_exists( $processed_terms[ intval( $term['parent'] ) ], $term['taxonomy'] );
		if ( is_array( $parent ) ) $parent = $parent['term_id'];
	}

	$id = wp_insert_term( $term['name'], $term['taxonomy'], array(
		'parent' => $parent,
		'slug' => $term['slug'],
		'description' => $term['description'],
	) );
	if ( ! is_wp_error( $id ) ) {
		if ( isset( $term['term_id'] ) ) {
			// success!
			$processed_terms[ intval($term['term_id']) ] = $id['term_id'];
			if ( isset( $term['thumbnail'] ) ) {
				themify_add_import_action( 'term_thumb', array(
					'id' => $id['term_id'],
					'thumb' => $term['thumbnail'],
				) );
			}
			return $term['term_id'];
		}
	}

	return false;
}

function themify_get_term_id_by_slug( $slug, $tax ) {
	$term = get_term_by( 'slug', $slug, $tax );
	if( $term ) {
		return $term->term_id;
	}

	return false;
}

function themify_undo_import_term( $term ) {
	$term_id = term_exists( $term['slug'], $term['taxonomy'] );
	if ( $term_id ) {
		if ( is_array( $term_id ) ) $term_id = $term_id['term_id'];

		if ( $term_thumbnail = get_term_meta( $term['term_id'], 'thumbnail_id', true ) ) {
			wp_delete_attachment( $term_thumbnail, true );
		}

		if ( isset( $term_id ) ) {
			wp_delete_term( $term_id, $term['taxonomy'] );
		}
	}
}

/**
 * Determine if a post exists based on title, content, and date
 *
 * @global wpdb $wpdb WordPress database abstraction object.
 *
 * @param array $args array of database parameters to check
 * @return int Post ID if post exists, 0 otherwise.
 */
function themify_post_exists( $args = array() ) {
	global $wpdb;

	$query = "SELECT ID FROM $wpdb->posts WHERE 1=1";
	$db_args = array();

	foreach ( $args as $key => $value ) {
		$value = wp_unslash( sanitize_post_field( $key, $value, 0, 'db' ) );
		if( ! empty( $value ) ) {
			$query .= ' AND ' . $key . ' = %s';
			$db_args[] = $value;
		}
	}

	if ( !empty ( $args ) )
		return (int) $wpdb->get_var( $wpdb->prepare($query, $args) );

	return 0;
}

function themify_undo_import_post( $post ) {
	if( $post['post_type'] == 'nav_menu_item' ) {
		$post_exists = themify_post_exists( array(
			'post_name' => $post['post_name'],
			'post_modified' => $post['post_date'],
			'post_type' => 'nav_menu_item',
		) );
	} else {
		$post_exists = post_exists( $post['post_title'], '', $post['post_date'] );
	}
	if( $post_exists && get_post_type( $post_exists ) == $post['post_type'] ) {
		/**
		 * check if the post has been modified, if so leave it be
		 *
		 * NOTE: posts are imported using wp_insert_post() which modifies post_modified field
		 * to be the same as post_date, hence to check if the post has been modified,
		 * the post_modified field is compared against post_date in the original post.
		 */
		if( $post['post_date'] == get_post_field( 'post_modified', $post_exists ) ) {
			// find and remove all post attachments
			$attachments = get_posts( array(
				'post_type' => 'attachment',
				'posts_per_page' => -1,
				'post_parent' => $post_exists,
			) );
			if ( $attachments ) {
				foreach ( $attachments as $attachment ) {
					wp_delete_attachment( $attachment->ID, true );
				}
			}
			wp_delete_post( $post_exists, true ); // true: bypass trash
		}
	}
}

function themify_process_post_import( $post ) {
	if( ERASEDEMO ) {
		themify_undo_import_post( $post );
	} else {
		if ( $id = themify_import_post( $post ) ) {
			if ( defined( 'IMPORT_IMAGES' ) && ! IMPORT_IMAGES ) {
				/* if importing images is disabled and post is supposed to have a thumbnail, create a placeholder image instead */
				if ( isset( $post['thumb'] ) ) { // the post is supposed to have featured image
					$placeholder = themify_get_placeholder_image();
					if( ! is_wp_error( $placeholder ) ) {
						set_post_thumbnail( $id, $placeholder );
					}
				}
			} else {
				if ( isset( $post["thumb"] ) ) {
					themify_add_import_action( 'post_thumb', array(
						'id' => $id,
						'thumb' => $post["thumb"],
					) );
				}
				if ( isset( $post["gallery_shortcode"] ) ) {
					themify_add_import_action( 'gallery_field', array(
						'id' => $id,
						'fields' => $post["gallery_shortcode"],
					) );
				}
				if ( isset( $post["_product_image_gallery"] ) ) {
					themify_add_import_action( 'product_gallery', array(
						'id' => $id,
						'images' => $post["_product_image_gallery"],
					) );
				}
			}
		}
	}
}
$thumbs = array();
function themify_do_demo_import() {
global $import_actions;

	if ( isset( $GLOBALS["ThemifyBuilder_Data_Manager"] ) ) {
		remove_action( "save_post", array( $GLOBALS["ThemifyBuilder_Data_Manager"], "save_builder_text_only"), 10, 3 );
	}
$term = array (
  'term_id' => 3,
  'name' => 'Blog',
  'slug' => 'blog',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 4,
  'name' => 'Travel',
  'slug' => 'travel',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 5,
  'name' => 'Photos',
  'slug' => 'photos',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 6,
  'name' => 'Featured',
  'slug' => 'featured',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 12,
  'name' => 'Images',
  'slug' => 'images',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 13,
  'name' => 'News',
  'slug' => 'news',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 15,
  'name' => 'Top Stories',
  'slug' => 'top-stories',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => '',
  'parent' => 13,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 21,
  'name' => 'gallery',
  'slug' => 'gallery-2',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 9,
  'name' => 'Main Navigation',
  'slug' => 'main-navigation',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 10,
  'name' => 'Top Navigation',
  'slug' => 'top-navigation',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$term = array (
  'term_id' => 11,
  'name' => 'Footer Navigation',
  'slug' => 'footer-navigation',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);

if( ERASEDEMO ) {
	themify_undo_import_term( $term );
} else {
	themify_import_term( $term );
}

$post = array (
  'ID' => 1811,
  'post_date' => '2008-06-26 00:46:53',
  'post_date_gmt' => '2008-06-26 00:46:53',
  'post_content' => 'Duis diam urna, aliquam id mauris nec, tristique ultrices turpis. Nam non ante in nunc euismod rutrum. Cras tristique feugiat neque sed vestibulum.',
  'post_title' => 'Shop on the Run',
  'post_excerpt' => '',
  'post_name' => 'shop-on-the-run',
  'post_modified' => '2017-08-21 11:53:59',
  'post_modified_gmt' => '2017-08-21 11:53:59',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=1811',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'featured, top-stories',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/106564386.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1808,
  'post_date' => '2008-06-26 00:45:33',
  'post_date_gmt' => '2008-06-26 00:45:33',
  'post_content' => 'Duis laoreet tortor magna, sit amet viverra elit dignissim sit amet. Aenean tempor et tortor eget blandit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed aliquam, sapien et tincidunt sodales, risus lectus rutrum turpis.',
  'post_title' => 'Greenhouse Plants',
  'post_excerpt' => '',
  'post_name' => 'greenhouse-plants',
  'post_modified' => '2017-08-21 11:54:01',
  'post_modified_gmt' => '2017-08-21 11:54:01',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=1808',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
    'category' => 'top-stories',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/86807268.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1805,
  'post_date' => '2008-06-26 00:44:06',
  'post_date_gmt' => '2008-06-26 00:44:06',
  'post_content' => 'Fusce hendrerit adipiscing diam vitae sodales. Sed faucibus venenatis lectus sed laoreet. Sed in libero ac nisi placerat dictum. Donec dui neque, aliquam non nunc nec, porttitor tempor leo. Maecenas non sagittis neque.',
  'post_title' => 'Morning News',
  'post_excerpt' => '',
  'post_name' => 'morning-news',
  'post_modified' => '2017-08-21 11:54:03',
  'post_modified_gmt' => '2017-08-21 11:54:03',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=1805',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
    'category' => 'top-stories',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/74878789.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1802,
  'post_date' => '2008-06-26 00:43:06',
  'post_date_gmt' => '2008-06-26 00:43:06',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam lobortis ac tellus id tempor. Aliquam pellentesque nibh quis justo commodo tristique. Aliquam erat volutpat. Etiam ut justo aliquam, euismod dolor eget, ullamcorper tortor. Aliquam eu ipsum a urna lacinia aliquam id non dui.',
  'post_title' => 'Travel the world',
  'post_excerpt' => '',
  'post_name' => 'travel-the-world',
  'post_modified' => '2017-08-21 11:54:05',
  'post_modified_gmt' => '2017-08-21 11:54:05',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=1802',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'top-stories, travel',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/83719858.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1775,
  'post_date' => '2008-06-25 02:04:40',
  'post_date_gmt' => '2008-06-25 02:04:40',
  'post_content' => 'Mauris varius fermentum velit sit amet varius. Aenean consectetur lacus tellus, sed vestibulum quam. Donec lorem lectus, posuere in pharetra at, vestibulum et magna. Ut viverra, risus eu commodo interdum, nunc ipsum mollis purus, ac varius ante purus sed diam.',
  'post_title' => 'How to Shop for Healthy Fruits',
  'post_excerpt' => '',
  'post_name' => 'how-to-shop-for-healthy-fruits',
  'post_modified' => '2017-08-21 11:54:06',
  'post_modified_gmt' => '2017-08-21 11:54:06',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=1775',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'featured',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/86527435.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1772,
  'post_date' => '2008-06-25 02:04:04',
  'post_date_gmt' => '2008-06-25 02:04:04',
  'post_content' => 'Vivamus in risus non lacus vehicula vestibulum. In magna leo, malesuada eget pulvinar ut, pellentesque a arcu. Praesent rutrum feugiat nibh elementum posuere. Nulla volutpat porta enim vel consectetur.',
  'post_title' => '10 Travel Tips for Your Summer Vacation',
  'post_excerpt' => '',
  'post_name' => '10-travel-tips-for-your-summer-vacation',
  'post_modified' => '2017-08-21 11:54:08',
  'post_modified_gmt' => '2017-08-21 11:54:08',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=1772',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'featured',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/106390351.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1769,
  'post_date' => '2008-06-25 02:03:33',
  'post_date_gmt' => '2008-06-25 02:03:33',
  'post_content' => 'Nunc et pharetra enim. Praesent pharetra, neque et luctus tempor, leo sapien faucibus leo, a dignissim turpis ipsum sed libero. Sed sed luctus purus. Aliquam faucibus turpis at libero consectetur euismod. Nam nunc lectus, congue non egestas quis, condimentum ut arcu.',
  'post_title' => 'Are Your Kids Under Stress?',
  'post_excerpt' => '',
  'post_name' => 'are-your-kids-under-stress',
  'post_modified' => '2017-08-21 11:54:09',
  'post_modified_gmt' => '2017-08-21 11:54:09',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=1769',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
    'category' => 'featured',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/83109689.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1766,
  'post_date' => '2008-06-25 02:02:31',
  'post_date_gmt' => '2008-06-25 02:02:31',
  'post_content' => 'Aliquam erat nulla, sodales at imperdiet vitae, convallis vel dui. Sed ultrices felis ut justo suscipit vestibulum. Pellentesque nisl nisi, vehicula vitae hendrerit vel, mattis eget mauris. Donec consequat eros eget lectus dictum sit amet ultrices neque sodales. Aliquam metus diam, mattis fringilla adipiscing at, lacinia at nulla.',
  'post_title' => 'How to Stay Connected on the Go',
  'post_excerpt' => '',
  'post_name' => 'how-to-stay-connected-on-the-go',
  'post_modified' => '2017-08-21 11:54:11',
  'post_modified_gmt' => '2017-08-21 11:54:11',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=1766',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
    'category' => 'featured',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/75627871.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1762,
  'post_date' => '2008-06-25 02:01:43',
  'post_date_gmt' => '2008-06-25 02:01:43',
  'post_content' => 'Nam risus velit, rhoncus eget consectetur id, <a href="https://themify.me/">Themify.me</a>. Vivamus imperdiet diam ac tortor tempus posuere. Curabitur at arcu id turpis posuere bibendum. Sed commodo mauris eget diam pretium cursus. In sagittis feugiat mauris, in ultrices mauris lacinia eu. Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit.',
  'post_title' => 'Top 10 Office Entertainment Gadgets',
  'post_excerpt' => '',
  'post_name' => 'top-10-office-entertainment-gadgets',
  'post_modified' => '2017-08-21 11:54:12',
  'post_modified_gmt' => '2017-08-21 11:54:12',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=1762',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
    'category' => 'featured',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/sb10064068ac-001.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 53,
  'post_date' => '2008-06-11 21:19:37',
  'post_date_gmt' => '2008-06-11 21:19:37',
  'post_content' => 'Mauris faucibus, tellus sed commodo luctus, nibh libero tristique felis, a vulputate nibh tellus et purus. Donec dictum odio non magna accumsan pellentesque. Sed pharetra fringilla venenatis. Quisque quis lobortis nibh, nec egestas leo.',
  'post_title' => 'Landscape',
  'post_excerpt' => 'Mauris faucibus, tellus sed commodo luctus, nibh libero tristique felis, a vulputate nibh...',
  'post_name' => 'landscape',
  'post_modified' => '2017-08-21 11:54:14',
  'post_modified_gmt' => '2017-08-21 11:54:14',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=53',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'blog, images, travel',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/65799673.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 50,
  'post_date' => '2008-06-11 21:16:04',
  'post_date_gmt' => '2008-06-11 21:16:04',
  'post_content' => 'Ut tempus nibh elit, eu faucibus lorem fringilla sed. Phasellus lobortis urna eget eleifend aliquet. Cras id augue id nulla interdum feugiat. Cras quam lacus, congue at consequat sit amet, consectetur id enim. Sed id lorem id turpis ultrices mattis at a odio.',
  'post_title' => 'External Link',
  'post_excerpt' => 'Ut tempus nibh elit, eu faucibus lorem fringilla sed. Phasellus lobortis urna eget.',
  'post_name' => 'external-link',
  'post_modified' => '2017-08-21 11:54:15',
  'post_modified_gmt' => '2017-08-21 11:54:15',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=50',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'external_link' => 'https://themify.me/',
  ),
  'tax_input' => 
  array (
    'category' => 'blog, images',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/59006500.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2083,
  'post_date' => '2008-06-11 21:08:52',
  'post_date_gmt' => '2008-06-11 21:08:52',
  'post_content' => 'Proin ornare scelerisque tellus, at porttitor urna pharetra in. Quisque mattis nibh sed dui fermentum, at porttitor nunc egestas. Vestibulum arcu eros, ultricies et ultricies scelerisque, gravida a eros. Nam eget commodo purus, quis mattis dui. Nunc vulputate rutrum odio vitae euismod.',
  'post_title' => 'Lightbox Video',
  'post_excerpt' => 'Proin ornare scelerisque tellus, at porttitor urna pharetra in. Quisque mattis nibh sed dui...',
  'post_name' => 'lightbox-video',
  'post_modified' => '2017-08-21 11:54:17',
  'post_modified_gmt' => '2017-08-21 11:54:17',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=46',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'lightbox_link' => 'http://vimeo.com/60779545',
    'lightbox_icon' => 'on',
  ),
  'tax_input' => 
  array (
    'category' => 'blog',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/26990563.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2082,
  'post_date' => '2008-06-11 20:58:56',
  'post_date_gmt' => '2008-06-11 20:58:56',
  'post_content' => 'Sed pharetra fringilla venenatis. Quisque quis lobortis nibh, nec egestas leo. Pellentesque ornare auctor velit eget rutrum. Vivamus enim quam, commodo auctor erat sed, sodales tristique erat.

[gallery link="file" columns="6" ids="36,37,38,39,40,41"]',
  'post_title' => 'Gallery Post',
  'post_excerpt' => 'Sed pharetra fringilla venenatis. Quisque quis lobortis nibh, nec egestas leo.',
  'post_name' => 'gallery-post',
  'post_modified' => '2017-08-21 11:54:18',
  'post_modified_gmt' => '2017-08-21 11:54:18',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=34',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'blog, images, photos',
    'post_tag' => 'gallery-2',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/56310136.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2081,
  'post_date' => '2008-06-11 20:45:36',
  'post_date_gmt' => '2008-06-11 20:45:36',
  'post_content' => 'Sed pharetra fringilla venenatis. Quisque quis lobortis nibh, nec egestas leo. Cras id augue id nulla interdum feugiat. Cras quam lacus, congue at consequat sit amet, consectetur id enim. Sed id lorem id turpis ultrices mattis at a odio.',
  'post_title' => 'Lightbox Link',
  'post_excerpt' => 'Sed pharetra fringilla venenatis. Quisque quis lobortis nibh, nec egestas leo.',
  'post_name' => 'lightbox-link',
  'post_modified' => '2017-08-21 11:54:20',
  'post_modified_gmt' => '2017-08-21 11:54:20',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=31',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'lightbox_link' => 'https://themify.me/demo/themes/builder/files/2013/06/129025022.jpg',
    'lightbox_icon' => 'on',
  ),
  'tax_input' => 
  array (
    'category' => 'blog, images',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/129025022.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2080,
  'post_date' => '2008-06-11 20:42:29',
  'post_date_gmt' => '2008-06-11 20:42:29',
  'post_content' => 'Vestibulum malesuada neque nec hendrerit lobortis. Maecenas erat diam, fringilla et hendrerit eu, laoreet vel quam. Integer sollicitudin nec eros a fringilla. Mauris sed velit sapien. Pellentesque habitant morbi tristique senectus et netus et malesuada.',
  'post_title' => 'Sweet Tooth',
  'post_excerpt' => 'Vestibulum malesuada neque nec hendrerit lobortis. Maecenas erat diam, fringilla...',
  'post_name' => 'sweet-tooth',
  'post_modified' => '2017-08-21 11:54:22',
  'post_modified_gmt' => '2017-08-21 11:54:22',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=28',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'blog, images, photos',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/99449315.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2079,
  'post_date' => '2008-06-11 20:41:16',
  'post_date_gmt' => '2008-06-11 20:41:16',
  'post_content' => 'Etiam ipsum ligula, mollis eu vestibulum id, ornare vel nibh. Sed sollicitudin, arcu non auctor pulvinar, velit eros viverra sapien, a mattis sem tortor sed arcu. Aenean gravida tincidunt commodo. In felis nunc, ultricies vel congue nec, congue vitae lacus.',
  'post_title' => 'Empty House',
  'post_excerpt' => 'Etiam ipsum ligula, mollis eu vestibulum id, ornare vel nibh. Sed sollicitudin, arcu non...',
  'post_name' => 'empty-house',
  'post_modified' => '2017-08-21 11:54:24',
  'post_modified_gmt' => '2017-08-21 11:54:24',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=25',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'blog, images, photos',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/92168305.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2078,
  'post_date' => '2008-06-11 20:38:30',
  'post_date_gmt' => '2008-06-11 20:38:30',
  'post_content' => 'Vestibulum a quam nisl. Nam sagittis neque erat, sed egestas urna facilisis et. Cras interdum imperdiet est, ac porttitor sapien porttitor id. Aenean semper congue dolor, non malesuada sapien. Sed neque diam, cursus eget eros at, pretium sagittis ligula. Sed pretium urna vitae velit pharetra',
  'post_title' => 'Late Stroll',
  'post_excerpt' => 'Vestibulum a quam nisl. Nam sagittis neque erat, sed egestas urna facilisis et.',
  'post_name' => 'late-stroll',
  'post_modified' => '2017-08-21 11:54:25',
  'post_modified_gmt' => '2017-08-21 11:54:25',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=22',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'blog, images, travel',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/134602640.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 8,
  'post_date' => '2008-06-11 20:27:11',
  'post_date_gmt' => '2008-06-11 20:27:11',
  'post_content' => 'Integer ultrices turpis laoreet tellus venenatis, sed luctus libero gravida. Vestibulum eu hendrerit eros. Quisque eget luctus turpis, eget cursus velit. Nullam auctor ligula velit, fringilla molestie elit mattis et. Donec volutpat adipiscing urna, at egestas odio venenatis aliquet.',
  'post_title' => 'Sunset',
  'post_excerpt' => 'Integer ultrices turpis laoreet tellus venenatis, sed luctus libero gravida.',
  'post_name' => 'sunset',
  'post_modified' => '2017-08-21 11:54:27',
  'post_modified_gmt' => '2017-08-21 11:54:27',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=8',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'blog, images, travel',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/60795601.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 6,
  'post_date' => '2008-06-11 20:22:47',
  'post_date_gmt' => '2008-06-11 20:22:47',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi ac lobortis orci, a ornare dui. Phasellus consequat vulputate dignissim. Etiam condimentum aliquam augue, a ullamcorper erat facilisis et. Proin congue augue sit amet ligula dictum porta. Integer pharetra euismod velit ac laoreet. Ut dictum vitae ligula sed fermentum. Sed dapibus purus sit amet massa faucibus varius. Proin nec malesuada libero.',
  'post_title' => 'Butterfly Light',
  'post_excerpt' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi ac lobortis orci...',
  'post_name' => 'butterfly-light',
  'post_modified' => '2017-08-21 11:54:29',
  'post_modified_gmt' => '2017-08-21 11:54:29',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/builder/?p=6',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'blog, images, photos',
  ),
  'thumb' => 'https://themify.me/demo/themes/responz/files/2013/06/127880648.jpg',
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1083,
  'post_date' => '2011-11-15 17:17:41',
  'post_date_gmt' => '2011-11-15 17:17:41',
  'post_content' => 'This is theme is built by <a href="https://themify.me">Themify WordPress Themes</a>. This is a sample page only. Aenean consectetur lacus tellus, sed vestibulum quam. Donec lorem lectus, posuere in pharetra at, vestibulum et magna. Ut viverra, risus eu commodo interdum, nunc ipsum mollis purus, ac varius ante purus sed diam. Vivamus in risus non lacus vehicula vestibulum. In magna leo, malesuada eget pulvinar ut, pellentesque a arcu. Praesent rutrum feugiat nibh elementum posuere. Nulla volutpat porta enim vel consectetur. Etiam orci eros, blandit nec egestas eget, pharetra eget leo. Morbi lobortis adipiscing massa tincidunt dignissim. Nulla lobortis laoreet risus, tempor accumsan sem congue vitae. Cras laoreet hendrerit erat, id porttitor nunc blandit adipiscing. Sed ac lacus metus, laoreet accumsan ante. In sit amet lacus ipsum, vitae bibendum diam. Donec ac massa ut nisl vulputate egestas ut quis tortor. Vivamus tristique
<h1>Heading 1</h1>
Aenean consectetur lacus tellus, sed vestibulum quam. Donec lorem lectus, posuere in pharetra at, vestibulum et magna. Ut viverra, risus eu commodo interdum, nunc ipsum mollis purus, ac varius ante purus sed diam. Vivamus in risus non lacus vehicula vestibulum. In magna leo, malesuada eget pulvinar ut, pellentesque a arcu.
<h2>Heading 2</h2>
Praesent rutrum feugiat nibh elementum posuere. Nulla volutpat porta enim vel consectetur. Etiam orci eros, blandit nec egestas eget, pharetra eget leo. Morbi lobortis adipiscing massa tincidunt dignissim. Nulla lobortis laoreet risus, tempor accumsan sem congue vitae.
<h3>Heading 3</h3>
Cras laoreet hendrerit erat, id porttitor nunc blandit adipiscing. Sed ac lacus metus, laoreet accumsan ante. In sit amet lacus ipsum, vitae bibendum diam.
<h4>Heading 4</h4>
Donec ac massa ut nisl vulputate egestas ut quis tortor. Vivamus tristique',
  'post_title' => 'About',
  'post_excerpt' => '',
  'post_name' => 'about',
  'post_modified' => '2017-08-21 11:55:14',
  'post_modified_gmt' => '2017-08-21 11:55:14',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/responz/?page_id=1083',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 594,
  'post_date' => '2011-04-03 01:15:51',
  'post_date_gmt' => '2011-04-03 01:15:51',
  'post_content' => 'Download this contact plugin: <a href="http://wordpress.org/extend/plugins/contact-form-7">Contact Form 7</a>.

[contact-form 1 "Contact form 1"]',
  'post_title' => 'Contact',
  'post_excerpt' => '',
  'post_name' => 'contact',
  'post_modified' => '2017-08-21 11:55:16',
  'post_modified_gmt' => '2017-08-21 11:55:16',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/bizco/?page_id=594',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 596,
  'post_date' => '2011-04-03 01:17:48',
  'post_date_gmt' => '2011-04-03 01:17:48',
  'post_content' => '[col grid="3-2 first"]
[map address="Yonge St. and Eglinton Ave, Toronto, Ontario, Canada" width=100% height=600px]
[/col]

[col grid="3-1"]
<h3>Direction</h3>
We are located at Aliquam faucibus turpis at libero consectetur euismod. Nam nunc lectus, congue non egestas quis, condimentum ut arcu. Nulla placerat, tortor non egestas rutrum, mi turpis adipiscing dui, et mollis turpis tortor vel orci. Cras a fringilla nunc. Suspendisse volutpat, eros congue scelerisque iaculis, magna odio sodales dui, vitae vulputate elit metus ac arcu.
<h3>Address</h3>
123 Street Name,
City, Province
23446
<h3>Phone</h3>
236-298-2828
<h3>Hours</h3>
Mon - Fri : 11:00am - 10:00pm
Sat : 11:00am - 2:00pm
Sun : 12:00am - 11:00pm
[/col]',
  'post_title' => 'Map',
  'post_excerpt' => '',
  'post_name' => 'map',
  'post_modified' => '2017-08-21 11:55:18',
  'post_modified_gmt' => '2017-08-21 11:55:18',
  'post_content_filtered' => '',
  'post_parent' => 594,
  'guid' => 'https://themify.me/demo/themes/bizco/?page_id=596',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 928,
  'post_date' => '2011-05-03 20:08:47',
  'post_date_gmt' => '2011-05-03 20:08:47',
  'post_content' => 'You can upload custom image gallery.

[gallery link="file" columns="1" order="DESC"]',
  'post_title' => 'Gallery',
  'post_excerpt' => '',
  'post_name' => 'gallery',
  'post_modified' => '2017-08-21 11:55:20',
  'post_modified_gmt' => '2017-08-21 11:55:20',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/folo/?page_id=928',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 2353,
  'post_date' => '2014-08-28 21:29:53',
  'post_date_gmt' => '2014-08-28 21:29:53',
  'post_content' => '',
  'post_title' => 'Home',
  'post_excerpt' => '',
  'post_name' => 'home',
  'post_modified' => '2017-08-21 11:55:22',
  'post_modified_gmt' => '2017-08-21 11:55:22',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/responz/?page_id=2353',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'query_category' => '0',
    'posts_per_page' => '4',
    'image_width' => '476',
    'image_height' => '205',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 409,
  'post_date' => '2010-10-08 11:15:14',
  'post_date_gmt' => '2010-10-08 15:15:14',
  'post_content' => '',
  'post_title' => 'Layouts',
  'post_excerpt' => '',
  'post_name' => 'layouts',
  'post_modified' => '2017-08-21 11:58:29',
  'post_modified_gmt' => '2017-08-21 11:58:29',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://demo.themify.me/bizco',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'query_category' => '0',
    'layout' => 'list-thumb-image',
    'image_width' => '240',
    'image_height' => '160',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 542,
  'post_date' => '2011-04-03 00:52:10',
  'post_date_gmt' => '2011-04-03 00:52:10',
  'post_content' => '',
  'post_title' => 'Fullwidth',
  'post_excerpt' => '',
  'post_name' => 'fullwidth',
  'post_modified' => '2017-08-21 11:55:26',
  'post_modified_gmt' => '2017-08-21 11:55:26',
  'post_content_filtered' => '',
  'post_parent' => 409,
  'guid' => 'https://themify.me/demo/themes/bizco/?page_id=542',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'query_category' => '0',
    'image_width' => '980',
    'image_height' => '650',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 553,
  'post_date' => '2011-04-03 00:56:45',
  'post_date_gmt' => '2011-04-03 00:56:45',
  'post_content' => '',
  'post_title' => 'Full - 2 Column',
  'post_excerpt' => '',
  'post_name' => '2-column',
  'post_modified' => '2017-08-21 11:55:28',
  'post_modified_gmt' => '2017-08-21 11:55:28',
  'post_content_filtered' => '',
  'post_parent' => 542,
  'guid' => 'https://themify.me/demo/themes/bizco/?page_id=553',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'query_category' => '0',
    'layout' => 'grid2',
    'posts_per_page' => '8',
    'display_content' => 'none',
    'image_width' => '475',
    'image_height' => '270',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 559,
  'post_date' => '2011-04-03 01:00:03',
  'post_date_gmt' => '2011-04-03 01:00:03',
  'post_content' => '',
  'post_title' => 'Full - 2 Column Thumb',
  'post_excerpt' => '',
  'post_name' => '2-column-thumb',
  'post_modified' => '2017-08-21 11:55:29',
  'post_modified_gmt' => '2017-08-21 11:55:29',
  'post_content_filtered' => '',
  'post_parent' => 542,
  'guid' => 'https://themify.me/demo/themes/bizco/?page_id=559',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'query_category' => '0',
    'layout' => 'grid2-thumb',
    'posts_per_page' => '8',
    'image_width' => '240',
    'image_height' => '160',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 551,
  'post_date' => '2011-04-03 00:56:20',
  'post_date_gmt' => '2011-04-03 00:56:20',
  'post_content' => '',
  'post_title' => 'Full - 3 Column',
  'post_excerpt' => '',
  'post_name' => '3-column',
  'post_modified' => '2017-08-21 11:55:31',
  'post_modified_gmt' => '2017-08-21 11:55:31',
  'post_content_filtered' => '',
  'post_parent' => 542,
  'guid' => 'https://themify.me/demo/themes/bizco/?page_id=551',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'query_category' => '0',
    'layout' => 'grid3',
    'posts_per_page' => '9',
    'display_content' => 'none',
    'image_width' => '306',
    'image_height' => '200',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 547,
  'post_date' => '2011-04-03 00:53:59',
  'post_date_gmt' => '2011-04-03 00:53:59',
  'post_content' => '',
  'post_title' => 'Full - 4 Column',
  'post_excerpt' => '',
  'post_name' => '4-column',
  'post_modified' => '2017-08-21 11:55:33',
  'post_modified_gmt' => '2017-08-21 11:55:33',
  'post_content_filtered' => '',
  'post_parent' => 542,
  'guid' => 'https://themify.me/demo/themes/bizco/?page_id=547',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'query_category' => '0',
    'layout' => 'grid4',
    'posts_per_page' => '8',
    'display_content' => 'none',
    'image_width' => '222',
    'image_height' => '148',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 555,
  'post_date' => '2011-04-03 00:57:19',
  'post_date_gmt' => '2011-04-03 00:57:19',
  'post_content' => '',
  'post_title' => 'Full - Large Image List',
  'post_excerpt' => '',
  'post_name' => 'large-image-list',
  'post_modified' => '2017-08-21 11:55:34',
  'post_modified_gmt' => '2017-08-21 11:55:34',
  'post_content_filtered' => '',
  'post_parent' => 542,
  'guid' => 'https://themify.me/demo/themes/bizco/?page_id=555',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'query_category' => '0',
    'layout' => 'list-large-image',
    'posts_per_page' => '5',
    'image_width' => '500',
    'image_height' => '350',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 558,
  'post_date' => '2011-04-03 00:59:31',
  'post_date_gmt' => '2011-04-03 00:59:31',
  'post_content' => '',
  'post_title' => 'Full - Thumb Image List',
  'post_excerpt' => '',
  'post_name' => 'thumb-image-list',
  'post_modified' => '2017-03-03 07:16:54',
  'post_modified_gmt' => '2017-03-03 07:16:54',
  'post_content_filtered' => '',
  'post_parent' => 542,
  'guid' => 'https://themify.me/demo/themes/bizco/?page_id=557',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'query_category' => '0',
    'layout' => 'list-thumb-image',
    'image_width' => '240',
    'image_height' => '160',
    'builder_switch_frontend' => '0',
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"gutter\\":\\"gutter-default\\",\\"column_alignment\\":\\"col_align_top\\",\\"cols\\":[{\\"column_order\\":\\"0\\",\\"grid_class\\":\\"col-full\\",\\"grid_width\\":\\"\\",\\"modules\\":[],\\"styling\\":[],\\"element_id\\":\\"h4rv915\\"}],\\"styling\\":[],\\"element_id\\":\\"5tu8008\\"}]',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 576,
  'post_date' => '2011-04-03 01:09:14',
  'post_date_gmt' => '2011-04-03 01:09:14',
  'post_content' => '',
  'post_title' => 'Sidebar Right',
  'post_excerpt' => '',
  'post_name' => 'sidebar-right',
  'post_modified' => '2017-08-21 11:57:29',
  'post_modified_gmt' => '2017-08-21 11:57:29',
  'post_content_filtered' => '',
  'post_parent' => 409,
  'guid' => 'https://themify.me/demo/themes/bizco/?page_id=576',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar1',
    'query_category' => '0',
    'image_width' => '640',
    'image_height' => '350',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 582,
  'post_date' => '2011-04-03 01:10:24',
  'post_date_gmt' => '2011-04-03 01:10:24',
  'post_content' => '',
  'post_title' => 'SB Right - 2 Column',
  'post_excerpt' => '',
  'post_name' => '2-column',
  'post_modified' => '2017-08-21 11:57:32',
  'post_modified_gmt' => '2017-08-21 11:57:32',
  'post_content_filtered' => '',
  'post_parent' => 576,
  'guid' => 'https://themify.me/demo/themes/bizco/?page_id=582',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'query_category' => '0',
    'layout' => 'grid2',
    'posts_per_page' => '8',
    'image_width' => '240',
    'image_height' => '150',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 588,
  'post_date' => '2011-04-03 01:11:50',
  'post_date_gmt' => '2011-04-03 01:11:50',
  'post_content' => '',
  'post_title' => 'SB Right - 2 Column Thumb',
  'post_excerpt' => '',
  'post_name' => '2-column-thumb',
  'post_modified' => '2017-08-21 11:57:34',
  'post_modified_gmt' => '2017-08-21 11:57:34',
  'post_content_filtered' => '',
  'post_parent' => 576,
  'guid' => 'https://themify.me/demo/themes/bizco/?page_id=588',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar1',
    'query_category' => '0',
    'layout' => 'grid2-thumb',
    'posts_per_page' => '8',
    'image_width' => '300',
    'image_height' => '180',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 580,
  'post_date' => '2011-04-03 01:10:05',
  'post_date_gmt' => '2011-04-03 01:10:05',
  'post_content' => '',
  'post_title' => 'SB Right - 3 Column',
  'post_excerpt' => '',
  'post_name' => '3-column',
  'post_modified' => '2017-08-21 11:57:36',
  'post_modified_gmt' => '2017-08-21 11:57:36',
  'post_content_filtered' => '',
  'post_parent' => 576,
  'guid' => 'https://themify.me/demo/themes/bizco/?page_id=580',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'query_category' => '0',
    'layout' => 'grid3',
    'posts_per_page' => '9',
    'image_width' => '240',
    'image_height' => '150',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 578,
  'post_date' => '2011-04-03 01:09:38',
  'post_date_gmt' => '2011-04-03 01:09:38',
  'post_content' => '',
  'post_title' => 'SB Right - 4 Column',
  'post_excerpt' => '',
  'post_name' => '4-column',
  'post_modified' => '2017-08-21 11:57:37',
  'post_modified_gmt' => '2017-08-21 11:57:37',
  'post_content_filtered' => '',
  'post_parent' => 576,
  'guid' => 'https://themify.me/demo/themes/bizco/?page_id=578',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar1',
    'query_category' => '0',
    'layout' => 'grid4',
    'posts_per_page' => '8',
    'image_width' => '240',
    'image_height' => '140',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 584,
  'post_date' => '2011-04-03 01:10:47',
  'post_date_gmt' => '2011-04-03 01:10:47',
  'post_content' => '',
  'post_title' => 'SB Right - Large Image List',
  'post_excerpt' => '',
  'post_name' => 'large-image-list',
  'post_modified' => '2017-08-21 11:57:39',
  'post_modified_gmt' => '2017-08-21 11:57:39',
  'post_content_filtered' => '',
  'post_parent' => 576,
  'guid' => 'https://themify.me/demo/themes/bizco/?page_id=584',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar1',
    'query_category' => '0',
    'layout' => 'list-large-image',
    'posts_per_page' => '5',
    'image_width' => '360',
    'image_height' => '240',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 586,
  'post_date' => '2011-04-03 01:11:13',
  'post_date_gmt' => '2011-04-03 01:11:13',
  'post_content' => '',
  'post_title' => 'SB Right - Thumb Image List',
  'post_excerpt' => '',
  'post_name' => 'thumb-image-list',
  'post_modified' => '2017-08-21 11:57:41',
  'post_modified_gmt' => '2017-08-21 11:57:41',
  'post_content_filtered' => '',
  'post_parent' => 576,
  'guid' => 'https://themify.me/demo/themes/bizco/?page_id=586',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar1',
    'query_category' => '0',
    'layout' => 'list-thumb-image',
    'image_width' => '220',
    'image_height' => '140',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1055,
  'post_date' => '2011-11-15 17:00:39',
  'post_date_gmt' => '2011-11-15 17:00:39',
  'post_content' => '',
  'post_title' => 'Sidebar2 Left',
  'post_excerpt' => '',
  'post_name' => 'sidebar2-left',
  'post_modified' => '2017-08-21 11:57:43',
  'post_modified_gmt' => '2017-08-21 11:57:43',
  'post_content_filtered' => '',
  'post_parent' => 409,
  'guid' => 'https://themify.me/demo/themes/responz/?page_id=1055',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar2 content-right',
    'query_category' => '0',
    'image_width' => '475',
    'image_height' => '280',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1068,
  'post_date' => '2011-11-15 17:04:49',
  'post_date_gmt' => '2011-11-15 17:04:49',
  'post_content' => '',
  'post_title' => 'SB2 Left - 2 Column',
  'post_excerpt' => '',
  'post_name' => 'sb2-left-2-column',
  'post_modified' => '2017-08-21 11:57:45',
  'post_modified_gmt' => '2017-08-21 11:57:45',
  'post_content_filtered' => '',
  'post_parent' => 1055,
  'guid' => 'https://themify.me/demo/themes/responz/?page_id=1068',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar2 content-right',
    'query_category' => '0',
    'layout' => 'grid2',
    'image_width' => '240',
    'image_height' => '150',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1070,
  'post_date' => '2011-11-15 17:05:27',
  'post_date_gmt' => '2011-11-15 17:05:27',
  'post_content' => '',
  'post_title' => 'SB2 Left - 2 Column Thumb',
  'post_excerpt' => '',
  'post_name' => 'sb2-left-2-column-thumb',
  'post_modified' => '2017-08-21 11:57:47',
  'post_modified_gmt' => '2017-08-21 11:57:47',
  'post_content_filtered' => '',
  'post_parent' => 1055,
  'guid' => 'https://themify.me/demo/themes/responz/?page_id=1070',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar2 content-right',
    'query_category' => '0',
    'layout' => 'grid2-thumb',
    'image_width' => '60',
    'image_height' => '60',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1066,
  'post_date' => '2011-11-15 17:04:18',
  'post_date_gmt' => '2011-11-15 17:04:18',
  'post_content' => '',
  'post_title' => 'SB2 Left - 3 Column',
  'post_excerpt' => '',
  'post_name' => 'sb2-left-3-column',
  'post_modified' => '2017-08-21 11:57:49',
  'post_modified_gmt' => '2017-08-21 11:57:49',
  'post_content_filtered' => '',
  'post_parent' => 1055,
  'guid' => 'https://themify.me/demo/themes/responz/?page_id=1066',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar2 content-right',
    'query_category' => '0',
    'layout' => 'grid3',
    'image_width' => '240',
    'image_height' => '140',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1064,
  'post_date' => '2011-11-15 17:01:46',
  'post_date_gmt' => '2011-11-15 17:01:46',
  'post_content' => '',
  'post_title' => 'SB2 Left - 4 Column',
  'post_excerpt' => '',
  'post_name' => 'sb2-left-4-column',
  'post_modified' => '2017-08-21 11:57:50',
  'post_modified_gmt' => '2017-08-21 11:57:50',
  'post_content_filtered' => '',
  'post_parent' => 1055,
  'guid' => 'https://themify.me/demo/themes/responz/?page_id=1064',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar2 content-right',
    'query_category' => '0',
    'layout' => 'grid4',
    'image_width' => '110',
    'image_height' => '70',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1072,
  'post_date' => '2011-11-15 17:06:05',
  'post_date_gmt' => '2011-11-15 17:06:05',
  'post_content' => '',
  'post_title' => 'SB2 Left - Large Image List',
  'post_excerpt' => '',
  'post_name' => 'sb2-left-large-image-list',
  'post_modified' => '2017-08-21 11:57:52',
  'post_modified_gmt' => '2017-08-21 11:57:52',
  'post_content_filtered' => '',
  'post_parent' => 1055,
  'guid' => 'https://themify.me/demo/themes/responz/?page_id=1072',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar2 content-right',
    'query_category' => '0',
    'layout' => 'list-large-image',
    'image_width' => '260',
    'image_height' => '160',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1074,
  'post_date' => '2011-11-15 17:06:33',
  'post_date_gmt' => '2011-11-15 17:06:33',
  'post_content' => '',
  'post_title' => 'SB2 Left - Thumb Image List',
  'post_excerpt' => '',
  'post_name' => 'sb2-left-thumb-image-list',
  'post_modified' => '2017-08-21 11:57:54',
  'post_modified_gmt' => '2017-08-21 11:57:54',
  'post_content_filtered' => '',
  'post_parent' => 1055,
  'guid' => 'https://themify.me/demo/themes/responz/?page_id=1074',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar2 content-right',
    'query_category' => '0',
    'layout' => 'list-thumb-image',
    'image_width' => '150',
    'image_height' => '100',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1086,
  'post_date' => '2011-11-15 17:27:02',
  'post_date_gmt' => '2011-11-15 17:27:02',
  'post_content' => '',
  'post_title' => 'Sidebar2 Right',
  'post_excerpt' => '',
  'post_name' => 'sidebar2-right',
  'post_modified' => '2017-08-21 11:58:31',
  'post_modified_gmt' => '2017-08-21 11:58:31',
  'post_content_filtered' => '',
  'post_parent' => 409,
  'guid' => 'https://themify.me/demo/themes/responz/?page_id=1086',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar2 content-left',
    'query_category' => '0',
    'image_width' => '475',
    'image_height' => '280',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1092,
  'post_date' => '2011-11-15 17:28:45',
  'post_date_gmt' => '2011-11-15 17:28:45',
  'post_content' => '',
  'post_title' => 'SB2 Right - 2 Column',
  'post_excerpt' => '',
  'post_name' => 'sb2-right-2-column',
  'post_modified' => '2017-08-21 11:58:33',
  'post_modified_gmt' => '2017-08-21 11:58:33',
  'post_content_filtered' => '',
  'post_parent' => 1086,
  'guid' => 'https://themify.me/demo/themes/responz/?page_id=1092',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar2 content-left',
    'query_category' => '0',
    'layout' => 'grid2',
    'image_width' => '240',
    'image_height' => '150',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1098,
  'post_date' => '2011-11-15 17:30:49',
  'post_date_gmt' => '2011-11-15 17:30:49',
  'post_content' => '',
  'post_title' => 'SB2 Right - 2 Column Thumb',
  'post_excerpt' => '',
  'post_name' => 'sb2-right-2-column-thumb',
  'post_modified' => '2017-08-21 11:58:34',
  'post_modified_gmt' => '2017-08-21 11:58:34',
  'post_content_filtered' => '',
  'post_parent' => 1086,
  'guid' => 'https://themify.me/demo/themes/responz/?page_id=1098',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar2 content-left',
    'query_category' => '0',
    'layout' => 'grid2-thumb',
    'image_width' => '240',
    'image_height' => '150',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1090,
  'post_date' => '2011-11-15 17:28:04',
  'post_date_gmt' => '2011-11-15 17:28:04',
  'post_content' => '',
  'post_title' => 'SB2 Right - 3 Column',
  'post_excerpt' => '',
  'post_name' => 'sb2-right-3-column',
  'post_modified' => '2017-08-21 11:58:36',
  'post_modified_gmt' => '2017-08-21 11:58:36',
  'post_content_filtered' => '',
  'post_parent' => 1086,
  'guid' => 'https://themify.me/demo/themes/responz/?page_id=1090',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar2 content-left',
    'query_category' => '0',
    'layout' => 'grid3',
    'image_width' => '240',
    'image_height' => '140',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1088,
  'post_date' => '2011-11-15 17:27:26',
  'post_date_gmt' => '2011-11-15 17:27:26',
  'post_content' => '',
  'post_title' => 'SB2 Right - 4 Column',
  'post_excerpt' => '',
  'post_name' => 'sb2-right-4-column',
  'post_modified' => '2017-08-21 11:58:37',
  'post_modified_gmt' => '2017-08-21 11:58:37',
  'post_content_filtered' => '',
  'post_parent' => 1086,
  'guid' => 'https://themify.me/demo/themes/responz/?page_id=1088',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar2 content-left',
    'query_category' => '0',
    'layout' => 'grid4',
    'image_width' => '110',
    'image_height' => '70',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1094,
  'post_date' => '2011-11-15 17:29:36',
  'post_date_gmt' => '2011-11-15 17:29:36',
  'post_content' => '',
  'post_title' => 'SB2 Right - Large Image List',
  'post_excerpt' => '',
  'post_name' => 'sb2-right-large-image-list',
  'post_modified' => '2017-08-21 11:58:39',
  'post_modified_gmt' => '2017-08-21 11:58:39',
  'post_content_filtered' => '',
  'post_parent' => 1086,
  'guid' => 'https://themify.me/demo/themes/responz/?page_id=1094',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar2 content-left',
    'query_category' => '0',
    'layout' => 'list-large-image',
    'image_width' => '260',
    'image_height' => '160',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1096,
  'post_date' => '2011-11-15 17:30:03',
  'post_date_gmt' => '2011-11-15 17:30:03',
  'post_content' => '',
  'post_title' => 'SB2 Right - Thumb Image List',
  'post_excerpt' => '',
  'post_name' => 'sb2-right-thumb-image-list',
  'post_modified' => '2017-08-21 11:58:40',
  'post_modified_gmt' => '2017-08-21 11:58:40',
  'post_content_filtered' => '',
  'post_parent' => 1086,
  'guid' => 'https://themify.me/demo/themes/responz/?page_id=1096',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar2 content-left',
    'query_category' => '0',
    'layout' => 'list-thumb-image',
    'image_width' => '150',
    'image_height' => '100',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 408,
  'post_date' => '2010-10-06 21:16:00',
  'post_date_gmt' => '2010-10-07 01:16:00',
  'post_content' => '<h3>Buttons</h3>
[button style="orange" link="https://themify.me"]Orange[/button] [button style="blue"]Blue[/button] [button style="pink"]Pink[/button] [button style="green"]Green[/button] [button style="red"]Red[/button] [button style="black"]Black[/button]

[hr]

[button style="small"]Small[/button]

[button]Default[/button]

[button style="large"]Large[/button] [button style="xlarge"]Xlarge[/button]

[hr]

[button style="orange small"]Orange Small[/button] [button style="blue"]Blue[/button] [button style="green large"]Green Large[/button] [button style="red xlarge"]Red Xlarge[/button]

[hr]
<h3>Columns</h3>
[col grid="2-1 first"]
<h4>col 2-1</h4>
Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eg.

[/col]

[col grid="2-1"]
<h4>col 2-1</h4>
Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa.

[/col]

[hr]

[col grid="3-1 first"]
<h4>col 3-1</h4>
Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eg.

[/col]

[col grid="3-1"]
<h4>col 3-1</h4>
Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa.

[/col]

[col grid="3-1"]
<h4>col 3-1</h4>
Vivamus dignissim, ligula velt pretium leo, vel placerat ipsum risus luctus purus. Tos, sed eleifend arcu. Donec porttitor hendrerit.

[/col]

[hr]

[col grid="4-1 first"]
<h4>col 4-1</h4>
Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget co.

[/col]

[col grid="4-1"]
<h4>col 4-1</h4>
Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis mas.

[/col]

[col grid="4-1"]
<h4>col 4-1</h4>
Vivamus dignissim, ligula velt pretium leo, vel placerat ipsum risus luctus purus. Tos, sed eleifend arcu. Donec porttitor hendrerit diam.

[/col]

[col grid="4-1"]
<h4>col 4-1</h4>
Donec porttitor hendrerit diam et blandit. Curabitur vel risus eros, sed eleifend arcu. Curabitur vitae velit ligula, vitae lobortis mas.

[/col]

[hr]

[col grid="4-2 first"]
<h4>col 4-2</h4>
Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget cout rhoncus turpis augue vitae libero.

[/col]

[col grid="4-1"]
<h4>col 4-1</h4>
Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis mas.

[/col]

[col grid="4-1"]
<h4>col 4-1</h4>
Vivamus dignissim, ligula velt pretium leo, vel placerat ipsum risus luctus purus. Tos, sed eleifend arcu. Donec porttitor hendrerit diam.

[/col]
<h3>Horizontal Rules</h3>
[hr]

[hr color="pink"]

[hr color="red"]

[hr color="light-gray"]

[hr color="dark-gray"]

[hr color="black"]

[hr color="orange"]

[hr color="yellow"]

[hr color="white"]
<h3>Quote</h3>
[quote]Vivamus in risus non lacus vehicula vestibulum. In magna leo, malesuada eget pulvinar ut, pellentesque a arcu. Praesent rutrum feugiat nibh elementum posuere. Nulla volutpat porta enim vel consectetur. Etiam orci eros, blandit nec egestas eget, pharetra eget leo. Morbi lobortis adipiscing massa tincidunt dignissim. Nulla lobortis laoreet risus, tempor accumsan sem congue vitae. Cras laoreet hendrerit erat, id porttitor nunc blandit adipiscing. [/quote]
<h3>Map</h3>
[map address="Yonge St. and Eglinton Ave, Toronto, Ontario, Canada" width=100% height=400px]',
  'post_title' => 'Shortcodes',
  'post_excerpt' => '',
  'post_name' => 'shortcodes',
  'post_modified' => '2017-08-21 11:58:42',
  'post_modified_gmt' => '2017-08-21 11:58:42',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://demo.themify.me/bizco/?page_id=101',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'layout' => 'default',
    'display_content' => 'none',
  ),
  'tax_input' => 
  array (
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1049,
  'post_date' => '2011-11-15 16:41:29',
  'post_date_gmt' => '2011-11-15 16:41:29',
  'post_content' => '',
  'post_title' => 'Home',
  'post_excerpt' => '',
  'post_name' => 'home-3',
  'post_modified' => '2011-11-16 16:28:28',
  'post_modified_gmt' => '2011-11-16 16:28:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1049',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '1049',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => 'https://themify.me/demo/themes/responz/',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'footer-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1050,
  'post_date' => '2011-11-15 16:41:29',
  'post_date_gmt' => '2011-11-15 16:41:29',
  'post_content' => 'Download this contact plugin: Contact Form 7.

[contact-form 1 "Contact form 1"] ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1050',
  'post_modified' => '2011-11-16 16:28:28',
  'post_modified_gmt' => '2011-11-16 16:28:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1050',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '594',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'footer-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1051,
  'post_date' => '2011-11-15 16:41:29',
  'post_date_gmt' => '2011-11-15 16:41:29',
  'post_content' => '[col grid="3-2 first"]
[map address="Yonge St. and Eglinton Ave, Toronto, Ontario, Canada" width=100% height=600px]
[/col]

[col grid="3-1"]
Direction
We are located at Aliquam faucibus turpis at libero consectetur euismod. Nam nunc lectus, congue non egestas quis, condimentum ut arcu. Nulla placerat, tortor non egestas rutrum, mi turpis adipiscing dui, et mollis turpis tortor vel orci. Cras a fringilla nunc. Suspendisse volutpat, eros congue scelerisque iaculis, magna odio sodales dui, vitae vulputate elit metus ac arcu.
Address
123 Street Name,
City, Province
23446
Phone
236-298-2828
Hours
Mon – Fri : 11:00am – 10:00pm
Sat : 11:00am – 2:00pm
Sun : 12:00am – 11:00pm
[/col] ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1051',
  'post_modified' => '2011-11-16 16:28:28',
  'post_modified_gmt' => '2011-11-16 16:28:28',
  'post_content_filtered' => '',
  'post_parent' => 594,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1051',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '596',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'footer-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1053,
  'post_date' => '2011-11-15 16:41:29',
  'post_date_gmt' => '2011-11-15 16:41:29',
  'post_content' => 'Buttons
[button style="orange" link="https://themify.me"]Orange[/button] [button style="blue"]Blue[/button] [button style="pink"]Pink[/button] [button style="green"]Green[/button] [button style="red"]Red[/button] [button style="black"]Black[/button]

[hr]

[button style="small"]Small[/button]

[button]Default[/button]

[button style="large"]Large[/button] [button style="xlarge"]Xlarge[/button]

[hr]

[button style="orange small"]Orange Small[/button] [button style="blue"]Blue[/button] [button style="green large"]Green Large[/button] [button style="red xlarge"]Red Xlarge[/button]

[hr]
Columns
[col grid="2-1 first"]
col 2-1
Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eg.

[/col]

[col grid="2-1"]
col 2-1
Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa.

[/col]

[hr]

[col grid="3-1 first"]
col 3-1
Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eg.

[/col]

[col grid="3-1"]
col 3-1
Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa.

[/col]

[col grid="3-1"]
col 3-1
Vivamus dignissim, ligula velt pretium leo, vel placerat ipsum risus luctus purus. Tos, sed eleifend arcu. Donec porttitor hendrerit.

[/col]

[hr]

[col grid="4-1 first"]
col 4-1
Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget co.

[/col]

[col grid="4-1"]
col 4-1
Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis mas.

[/col]

[col grid="4-1"]
col 4-1
Vivamus dignissim, ligula velt pretium leo, vel placerat ipsum risus luctus purus. Tos, sed eleifend arcu. Donec porttitor hendrerit diam.

[/col]

[col grid="4-1"]
col 4-1
Donec porttitor hendrerit diam et blandit. Curabitur vel risus eros, sed eleifend arcu. Curabitur vitae velit ligula, vitae lobortis mas.

[/col]

[hr]

[col grid="4-2 first"]
col 4-2
Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget cout rhoncus turpis augue vitae libero.

[/col]

[col grid="4-1"]
col 4-1
Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis mas.

[/col]

[col grid="4-1"]
col 4-1
Vivamus dignissim, ligula velt pretium leo, vel placerat ipsum risus luctus purus. Tos, sed eleifend arcu. Donec porttitor hendrerit diam.

[/col]
Horizontal Rules
[hr]

[hr color="pink"]

[hr color="red"]

[hr color="light-gray"]

[hr color="dark-gray"]

[hr color="black"]

[hr color="orange"]

[hr color="yellow"]

[hr color="white"]
Quote
[quote]Vivamus in risus non lacus vehicula vestibulum. In magna leo, malesuada eget pulvinar ut, pellentesque a arcu. Praesent rutrum feugiat nibh elementum posuere. Nulla volutpat porta enim vel consectetur. Etiam orci eros, blandit nec egestas eget, pharetra eget leo. Morbi lobortis adipiscing massa tincidunt dignissim. Nulla lobortis laoreet risus, tempor accumsan sem congue vitae. Cras laoreet hendrerit erat, id porttitor nunc blandit adipiscing. [/quote]
Map
[map address="Yonge St. and Eglinton Ave, Toronto, Ontario, Canada" width=100% height=400px] ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1053',
  'post_modified' => '2011-11-16 16:28:28',
  'post_modified_gmt' => '2011-11-16 16:28:28',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1053',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '408',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'footer-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1019,
  'post_date' => '2011-11-15 16:33:12',
  'post_date_gmt' => '2011-11-15 16:33:12',
  'post_content' => '',
  'post_title' => 'Home',
  'post_excerpt' => 'sweet home',
  'post_name' => 'home-2',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1019',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'custom',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '1019',
    '_menu_item_object' => 'custom',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
    '_menu_item_url' => 'https://themify.me/demo/themes/responz/',
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1011,
  'post_date' => '2011-11-15 16:30:59',
  'post_date_gmt' => '2011-11-15 16:30:59',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => 'photos, etc.',
  'post_name' => '1011',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1011',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'taxonomy',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '4',
    '_menu_item_object' => 'category',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1047,
  'post_date' => '2011-11-15 16:36:08',
  'post_date_gmt' => '2011-11-15 16:36:08',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => 'articles',
  'post_name' => '1047',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1047',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'taxonomy',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '6',
    '_menu_item_object' => 'category',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1013,
  'post_date' => '2011-11-15 16:30:59',
  'post_date_gmt' => '2011-11-15 16:30:59',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => 'say cheeze',
  'post_name' => '1013',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1013',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'taxonomy',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '5',
    '_menu_item_object' => 'category',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1020,
  'post_date' => '2011-11-15 16:35:06',
  'post_date_gmt' => '2011-11-15 16:35:06',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => 'design options',
  'post_name' => '1020',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1020',
  'menu_order' => 5,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '409',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1021,
  'post_date' => '2011-11-15 16:35:06',
  'post_date_gmt' => '2011-11-15 16:35:06',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1021',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 409,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1021',
  'menu_order' => 6,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1020',
    '_menu_item_object_id' => '542',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1022,
  'post_date' => '2011-11-15 16:35:06',
  'post_date_gmt' => '2011-11-15 16:35:06',
  'post_content' => '',
  'post_title' => 'Full – 2 Column',
  'post_excerpt' => '',
  'post_name' => '1022',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 542,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1022',
  'menu_order' => 7,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1021',
    '_menu_item_object_id' => '553',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1023,
  'post_date' => '2011-11-15 16:35:06',
  'post_date_gmt' => '2011-11-15 16:35:06',
  'post_content' => '',
  'post_title' => 'Full – 2 Column Thumb',
  'post_excerpt' => '',
  'post_name' => '1023',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 542,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1023',
  'menu_order' => 8,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1021',
    '_menu_item_object_id' => '559',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1024,
  'post_date' => '2011-11-15 16:35:06',
  'post_date_gmt' => '2011-11-15 16:35:06',
  'post_content' => '',
  'post_title' => 'Full – 3 Column',
  'post_excerpt' => '',
  'post_name' => '1024',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 542,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1024',
  'menu_order' => 9,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1021',
    '_menu_item_object_id' => '551',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1025,
  'post_date' => '2011-11-15 16:35:06',
  'post_date_gmt' => '2011-11-15 16:35:06',
  'post_content' => '',
  'post_title' => 'Full – 4 Column',
  'post_excerpt' => '',
  'post_name' => '1025',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 542,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1025',
  'menu_order' => 10,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1021',
    '_menu_item_object_id' => '547',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1026,
  'post_date' => '2011-11-15 16:35:06',
  'post_date_gmt' => '2011-11-15 16:35:06',
  'post_content' => '',
  'post_title' => 'Full – Large Image List',
  'post_excerpt' => '',
  'post_name' => '1026',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 542,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1026',
  'menu_order' => 11,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1021',
    '_menu_item_object_id' => '555',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1027,
  'post_date' => '2011-11-15 16:35:06',
  'post_date_gmt' => '2011-11-15 16:35:06',
  'post_content' => '',
  'post_title' => 'Full – Thumb Image List',
  'post_excerpt' => '',
  'post_name' => '1027',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 542,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1027',
  'menu_order' => 12,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1021',
    '_menu_item_object_id' => '558',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1040,
  'post_date' => '2011-11-15 16:35:06',
  'post_date_gmt' => '2011-11-15 16:35:06',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1040',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 409,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1040',
  'menu_order' => 13,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1020',
    '_menu_item_object_id' => '576',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1041,
  'post_date' => '2011-11-15 16:35:06',
  'post_date_gmt' => '2011-11-15 16:35:06',
  'post_content' => '',
  'post_title' => 'SB Right – 2 Column',
  'post_excerpt' => '',
  'post_name' => '1041',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 576,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1041',
  'menu_order' => 14,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1040',
    '_menu_item_object_id' => '582',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1042,
  'post_date' => '2011-11-15 16:35:06',
  'post_date_gmt' => '2011-11-15 16:35:06',
  'post_content' => '',
  'post_title' => 'SB Right – 2 Column Thumb',
  'post_excerpt' => '',
  'post_name' => '1042',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 576,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1042',
  'menu_order' => 15,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1040',
    '_menu_item_object_id' => '588',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1043,
  'post_date' => '2011-11-15 16:35:06',
  'post_date_gmt' => '2011-11-15 16:35:06',
  'post_content' => '',
  'post_title' => 'SB Right – 3 Column',
  'post_excerpt' => '',
  'post_name' => '1043',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 576,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1043',
  'menu_order' => 16,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1040',
    '_menu_item_object_id' => '580',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1044,
  'post_date' => '2011-11-15 16:35:06',
  'post_date_gmt' => '2011-11-15 16:35:06',
  'post_content' => '',
  'post_title' => 'SB Right – 4 Column',
  'post_excerpt' => '',
  'post_name' => '1044',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 576,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1044',
  'menu_order' => 17,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1040',
    '_menu_item_object_id' => '578',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1045,
  'post_date' => '2011-11-15 16:35:06',
  'post_date_gmt' => '2011-11-15 16:35:06',
  'post_content' => '',
  'post_title' => 'SB Right – Large Image List',
  'post_excerpt' => '',
  'post_name' => '1045',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 576,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1045',
  'menu_order' => 18,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1040',
    '_menu_item_object_id' => '584',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1046,
  'post_date' => '2011-11-15 16:35:06',
  'post_date_gmt' => '2011-11-15 16:35:06',
  'post_content' => '',
  'post_title' => 'SB Right – Thumb Image List',
  'post_excerpt' => '',
  'post_name' => '1046',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 576,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1046',
  'menu_order' => 19,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1040',
    '_menu_item_object_id' => '586',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1076,
  'post_date' => '2011-11-15 17:07:14',
  'post_date_gmt' => '2011-11-15 17:07:14',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1076',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 409,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1076',
  'menu_order' => 20,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1020',
    '_menu_item_object_id' => '1055',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1077,
  'post_date' => '2011-11-15 17:07:14',
  'post_date_gmt' => '2011-11-15 17:07:14',
  'post_content' => '',
  'post_title' => 'SB2 Left – 2 Column',
  'post_excerpt' => '',
  'post_name' => '1077',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 1055,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1077',
  'menu_order' => 21,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1076',
    '_menu_item_object_id' => '1068',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1078,
  'post_date' => '2011-11-15 17:07:14',
  'post_date_gmt' => '2011-11-15 17:07:14',
  'post_content' => '',
  'post_title' => 'SB2 Left – 2 Column Thumb',
  'post_excerpt' => '',
  'post_name' => '1078',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 1055,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1078',
  'menu_order' => 22,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1076',
    '_menu_item_object_id' => '1070',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1079,
  'post_date' => '2011-11-15 17:07:14',
  'post_date_gmt' => '2011-11-15 17:07:14',
  'post_content' => '',
  'post_title' => 'SB2 Left – 3 Column',
  'post_excerpt' => '',
  'post_name' => '1079',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 1055,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1079',
  'menu_order' => 23,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1076',
    '_menu_item_object_id' => '1066',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1080,
  'post_date' => '2011-11-15 17:07:14',
  'post_date_gmt' => '2011-11-15 17:07:14',
  'post_content' => '',
  'post_title' => 'SB2 Left – 4 Column',
  'post_excerpt' => '',
  'post_name' => '1080',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 1055,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1080',
  'menu_order' => 24,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1076',
    '_menu_item_object_id' => '1064',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1081,
  'post_date' => '2011-11-15 17:07:14',
  'post_date_gmt' => '2011-11-15 17:07:14',
  'post_content' => '',
  'post_title' => 'SB2 Left – Large Image List',
  'post_excerpt' => '',
  'post_name' => '1081',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 1055,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1081',
  'menu_order' => 25,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1076',
    '_menu_item_object_id' => '1072',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1082,
  'post_date' => '2011-11-15 17:07:14',
  'post_date_gmt' => '2011-11-15 17:07:14',
  'post_content' => '',
  'post_title' => 'SB2 Left – Thumb Image List',
  'post_excerpt' => '',
  'post_name' => '1082',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 1055,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1082',
  'menu_order' => 26,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1076',
    '_menu_item_object_id' => '1074',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1106,
  'post_date' => '2011-11-15 17:32:20',
  'post_date_gmt' => '2011-11-15 17:32:20',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1106',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 409,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1106',
  'menu_order' => 27,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1020',
    '_menu_item_object_id' => '1086',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1100,
  'post_date' => '2011-11-15 17:32:20',
  'post_date_gmt' => '2011-11-15 17:32:20',
  'post_content' => '',
  'post_title' => 'SB2 Right – 2 Column Thumb',
  'post_excerpt' => '',
  'post_name' => '1100',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 1086,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1100',
  'menu_order' => 28,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1106',
    '_menu_item_object_id' => '1098',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1101,
  'post_date' => '2011-11-15 17:32:20',
  'post_date_gmt' => '2011-11-15 17:32:20',
  'post_content' => '',
  'post_title' => 'SB2 Right – Thumb Image List',
  'post_excerpt' => '',
  'post_name' => '1101',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 1086,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1101',
  'menu_order' => 29,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1106',
    '_menu_item_object_id' => '1096',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1102,
  'post_date' => '2011-11-15 17:32:20',
  'post_date_gmt' => '2011-11-15 17:32:20',
  'post_content' => '',
  'post_title' => 'SB2 Right – Large Image List',
  'post_excerpt' => '',
  'post_name' => '1102',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 1086,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1102',
  'menu_order' => 30,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1106',
    '_menu_item_object_id' => '1094',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1103,
  'post_date' => '2011-11-15 17:32:20',
  'post_date_gmt' => '2011-11-15 17:32:20',
  'post_content' => '',
  'post_title' => 'SB2 Right – 2 Column',
  'post_excerpt' => '',
  'post_name' => '1103',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 1086,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1103',
  'menu_order' => 31,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1106',
    '_menu_item_object_id' => '1092',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1104,
  'post_date' => '2011-11-15 17:32:20',
  'post_date_gmt' => '2011-11-15 17:32:20',
  'post_content' => '',
  'post_title' => 'SB2 Right – 3 Column',
  'post_excerpt' => '',
  'post_name' => '1104',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 1086,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1104',
  'menu_order' => 32,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1106',
    '_menu_item_object_id' => '1090',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1105,
  'post_date' => '2011-11-15 17:32:20',
  'post_date_gmt' => '2011-11-15 17:32:20',
  'post_content' => '',
  'post_title' => 'SB2 Right – 4 Column',
  'post_excerpt' => '',
  'post_name' => '1105',
  'post_modified' => '2017-10-28 15:31:45',
  'post_modified_gmt' => '2017-10-28 15:31:45',
  'post_content_filtered' => '',
  'post_parent' => 1086,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1105',
  'menu_order' => 33,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1106',
    '_menu_item_object_id' => '1088',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1085,
  'post_date' => '2011-11-15 17:18:31',
  'post_date_gmt' => '2011-11-15 17:18:31',
  'post_content' => 'This is theme is built by Themify WordPress Themes. This is a sample page only. Aenean consectetur lacus tellus, sed vestibulum quam. Donec lorem lectus, posuere in pharetra at, vestibulum et magna. Ut viverra, risus eu commodo interdum, nunc ipsum mollis purus, ac varius ante purus sed diam. Vivamus in risus non lacus vehicula vestibulum. In magna leo, malesuada eget pulvinar ut, pellentesque a arcu. Praesent rutrum feugiat nibh elementum posuere. Nulla volutpat porta enim vel consectetur. Etiam orci eros, blandit nec egestas eget, pharetra eget leo. Morbi lobortis adipiscing massa tincidunt dignissim. Nulla lobortis laoreet risus, tempor accumsan sem congue vitae. Cras laoreet hendrerit erat, id porttitor nunc blandit adipiscing. Sed ac lacus metus, laoreet accumsan ante. In sit amet lacus ipsum, vitae bibendum diam. Donec ac massa ut nisl vulputate egestas ut quis tortor. Vivamus tristique Heading 1 Aenean consectetur lacus tellus, sed vestibulum quam. Donec lorem lectus, posuere in pharetra at, vestibulum et magna. Ut viverra, risus eu commodo interdum, nunc ipsum mollis purus, ac varius ante purus sed diam. Vivamus in risus non lacus vehicula vestibulum. In magna leo, malesuada eget pulvinar ut, pellentesque a arcu. Heading 2 Praesent rutrum feugiat nibh elementum posuere. Nulla volutpat porta…',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1085',
  'post_modified' => '2012-05-02 22:08:20',
  'post_modified_gmt' => '2012-05-02 22:08:20',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1085',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '1083',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'top-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1132,
  'post_date' => '2012-05-02 21:29:50',
  'post_date_gmt' => '2012-05-02 21:29:50',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1132',
  'post_modified' => '2012-05-02 22:08:20',
  'post_modified_gmt' => '2012-05-02 22:08:20',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1132',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '928',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'top-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1134,
  'post_date' => '2012-05-02 22:08:20',
  'post_date_gmt' => '2012-05-02 22:08:20',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1134',
  'post_modified' => '2012-05-02 22:08:20',
  'post_modified_gmt' => '2012-05-02 22:08:20',
  'post_content_filtered' => '',
  'post_parent' => 1086,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1134',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1132',
    '_menu_item_object_id' => '1098',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'top-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1135,
  'post_date' => '2012-05-02 22:08:20',
  'post_date_gmt' => '2012-05-02 22:08:20',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1135',
  'post_modified' => '2012-05-02 22:08:20',
  'post_modified_gmt' => '2012-05-02 22:08:20',
  'post_content_filtered' => '',
  'post_parent' => 1086,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1135',
  'menu_order' => 4,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1132',
    '_menu_item_object_id' => '1096',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'top-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1136,
  'post_date' => '2012-05-02 22:08:20',
  'post_date_gmt' => '2012-05-02 22:08:20',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1136',
  'post_modified' => '2012-05-02 22:08:20',
  'post_modified_gmt' => '2012-05-02 22:08:20',
  'post_content_filtered' => '',
  'post_parent' => 1086,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1136',
  'menu_order' => 5,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '1132',
    '_menu_item_object_id' => '1094',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'top-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1048,
  'post_date' => '2011-11-15 16:37:19',
  'post_date_gmt' => '2011-11-15 16:37:19',
  'post_content' => '[col grid="3-2 first"] [map address="Yonge St. and Eglinton Ave, Toronto, Ontario, Canada" width=100% height=600px] [/col] [col grid="3-1"] Direction We are located at Aliquam faucibus turpis at libero consectetur euismod. Nam nunc lectus, congue non egestas quis, condimentum ut arcu. Nulla placerat, tortor non egestas rutrum, mi turpis adipiscing dui, et mollis turpis tortor vel orci. Cras a fringilla nunc. Suspendisse volutpat, eros congue scelerisque iaculis, magna odio sodales dui, vitae vulputate elit metus ac arcu. Address 123 Street Name, City, Province 23446 Phone 236-298-2828 Hours Mon – Fri : 11:00am – 10:00pm Sat : 11:00am – 2:00pm Sun : 12:00am – 11:00pm [/col]',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1048',
  'post_modified' => '2012-05-02 22:08:20',
  'post_modified_gmt' => '2012-05-02 22:08:20',
  'post_content_filtered' => '',
  'post_parent' => 594,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1048',
  'menu_order' => 6,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '596',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'top-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1130,
  'post_date' => '2012-05-02 21:29:50',
  'post_date_gmt' => '2012-05-02 21:29:50',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1130',
  'post_modified' => '2012-05-02 22:08:20',
  'post_modified_gmt' => '2012-05-02 22:08:20',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1130',
  'menu_order' => 7,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '594',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'top-navigation',
  ),
);
themify_process_post_import( $post );


$post = array (
  'ID' => 1133,
  'post_date' => '2012-05-02 21:29:50',
  'post_date_gmt' => '2012-05-02 21:29:50',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '1133',
  'post_modified' => '2012-05-02 22:08:20',
  'post_modified_gmt' => '2012-05-02 22:08:20',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/responz/?p=1133',
  'menu_order' => 8,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '408',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'top-navigation',
  ),
);
themify_process_post_import( $post );



function themify_import_get_term_id_from_slug( $slug ) {
	$menu = get_term_by( "slug", $slug, "nav_menu" );
	return is_wp_error( $menu ) ? 0 : (int) $menu->term_id;
}

	$widgets = get_option( "widget_themify-feature-posts" );
$widgets[1002] = array (
  'title' => 'Featured',
  'category' => '6',
  'show_count' => '3',
  'show_date' => 'on',
  'show_thumb' => 'on',
  'show_excerpt' => NULL,
  'hide_title' => NULL,
  'thumb_width' => '138',
  'thumb_height' => '70',
  'excerpt_length' => '55',
);
update_option( "widget_themify-feature-posts", $widgets );

$widgets = get_option( "widget_themify-twitter" );
$widgets[1003] = array (
  'title' => 'Latest Tweets',
  'username' => 'themify',
  'show_count' => '3',
  'hide_timestamp' => NULL,
  'hide_url' => 'on',
  'show_follow' => 'on',
  'follow_text' => '&rarr; Follow me',
);
update_option( "widget_themify-twitter", $widgets );

$widgets = get_option( "widget_themify-links" );
$widgets[1004] = array (
  'title' => 'Follow Us',
  'category' => '8',
  'orderby' => 'id',
  'show_count' => '10',
  'show_thumb' => 'on',
  'show_name' => 'on',
  'show_desc' => NULL,
);
update_option( "widget_themify-links", $widgets );

$widgets = get_option( "widget_themify-list-categories" );
$widgets[1005] = array (
  'title' => 'Categories',
  'parent' => '0',
  'depth' => '0',
  'orderby' => 'name',
  'exclude' => '',
  'show_dropdown' => NULL,
  'show_counts' => NULL,
  'show_hierarchy' => NULL,
);
update_option( "widget_themify-list-categories", $widgets );

$widgets = get_option( "widget_themify-flickr" );
$widgets[1006] = array (
  'title' => 'Recent Photos',
  'username' => '52839779@N02',
  'show_count' => '8',
);
update_option( "widget_themify-flickr", $widgets );

$widgets = get_option( "widget_themify-list-pages" );
$widgets[1007] = array (
  'title' => 'Pages',
  'parent' => '0',
  'depth' => '1',
  'orderby' => 'post_title',
  'exclude' => '',
);
update_option( "widget_themify-list-pages", $widgets );

$widgets = get_option( "widget_themify-recent-comments" );
$widgets[1008] = array (
  'title' => 'Comments',
  'show_count' => '3',
  'show_avatar' => 'on',
  'avatar_size' => '32',
  'excerpt_length' => '60',
);
update_option( "widget_themify-recent-comments", $widgets );

$widgets = get_option( "widget_text" );
$widgets[1009] = array (
  'title' => '',
  'text' => '<a href="https://themify.me" aria-label="banner ad"><img src="https://themify.me/demo/themes/responz/files/2011/11/468x60.png" alt="Advertisment"></a>',
  'filter' => false,
);
update_option( "widget_text", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1010] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-medium',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );



$sidebars_widgets = array (
  'sidebar-alt' => 
  array (
    0 => 'themify-feature-posts-1002',
  ),
  'sidebar-main' => 
  array (
    0 => 'themify-twitter-1003',
  ),
  'sidebar-main-2a' => 
  array (
    0 => 'themify-links-1004',
    1 => 'themify-list-categories-1005',
  ),
  'sidebar-main-2b' => 
  array (
    0 => 'themify-flickr-1006',
    1 => 'themify-list-pages-1007',
  ),
  'sidebar-main-3' => 
  array (
    0 => 'themify-recent-comments-1008',
  ),
  'header-widget' => 
  array (
    0 => 'text-1009',
  ),
  'social-widget' => 
  array (
    0 => 'themify-social-links-1010',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "top-navigation" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["top-nav"] = $menu[0]->term_id;
$menu = get_terms( "nav_menu", array( "slug" => "main-navigation" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
$menu = get_terms( "nav_menu", array( "slug" => "footer-navigation" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["footer-nav"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );


$homepage = get_posts( array( 'name' => 'home', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			
	ob_start(); ?>a:79:{s:21:"setting-webfonts_list";s:11:"recommended";s:22:"setting-default_layout";s:8:"sidebar2";s:27:"setting-default_post_layout";s:5:"grid2";s:30:"setting-default_layout_display";s:7:"excerpt";s:25:"setting-default_more_text";s:4:"More";s:21:"setting-index_orderby";s:4:"date";s:19:"setting-index_order";s:4:"DESC";s:31:"setting-image_post_feature_size";s:5:"blank";s:24:"setting-image_post_width";s:3:"240";s:25:"setting-image_post_height";s:3:"140";s:32:"setting-default_page_post_layout";s:8:"sidebar2";s:38:"setting-image_post_single_feature_size";s:5:"blank";s:31:"setting-image_post_single_width";s:3:"480";s:32:"setting-image_post_single_height";s:3:"280";s:27:"setting-default_page_layout";s:8:"sidebar2";s:40:"setting-custom_post_tglobal_style_single";s:8:"sidebar1";s:53:"setting-customizer_responsive_design_tablet_landscape";s:4:"1024";s:43:"setting-customizer_responsive_design_tablet";s:3:"768";s:43:"setting-customizer_responsive_design_mobile";s:3:"480";s:33:"setting-mobile_menu_trigger_point";s:3:"800";s:24:"setting-gallery_lightbox";s:8:"lightbox";s:26:"setting-page_builder_cache";s:2:"on";s:18:"setting-cache_gzip";s:2:"on";s:27:"setting-page_builder_expiry";s:1:"2";s:19:"setting-entries_nav";s:8:"numbered";s:29:"setting-header_slider_enabled";s:2:"on";s:29:"setting-header_slider_display";s:5:"posts";s:36:"setting-header_slider_posts_category";s:1:"6";s:34:"setting-header_slider_posts_slides";s:1:"6";s:37:"setting-header_slider_default_display";s:4:"none";s:29:"setting-header_slider_visible";s:1:"4";s:26:"setting-header_slider_auto";s:1:"0";s:28:"setting-header_slider_scroll";s:1:"1";s:27:"setting-header_slider_speed";s:2:".5";s:26:"setting-header_slider_wrap";s:3:"yes";s:29:"setting-footer_slider_enabled";s:2:"on";s:29:"setting-footer_slider_display";s:5:"posts";s:36:"setting-footer_slider_posts_category";s:1:"0";s:34:"setting-footer_slider_posts_slides";s:1:"6";s:37:"setting-footer_slider_default_display";s:4:"none";s:38:"setting-footer_slider_images_one_title";s:3:"one";s:37:"setting-footer_slider_images_one_link";s:1:"#";s:38:"setting-footer_slider_images_one_image";s:86:"https://themify.me/demo/themes/responz/files/2015/05/zU6fwmDaSVWZdCXcZfot_IMG_3838.jpg";s:29:"setting-footer_slider_visible";s:1:"4";s:26:"setting-footer_slider_auto";s:1:"0";s:28:"setting-footer_slider_scroll";s:1:"1";s:27:"setting-footer_slider_speed";s:2:".5";s:26:"setting-footer_slider_wrap";s:3:"yes";s:22:"setting-footer_widgets";s:17:"footerwidget-3col";s:25:"setting-img_php_base_size";s:5:"large";s:27:"setting-global_feature_size";s:5:"large";s:22:"setting-link_icon_type";s:10:"image-icon";s:32:"setting-link_type_themify-link-0";s:10:"image-icon";s:33:"setting-link_title_themify-link-0";s:7:"Twitter";s:32:"setting-link_link_themify-link-0";s:26:"http://twitter.com/themify";s:31:"setting-link_img_themify-link-0";s:95:"https://themify.me/demo/themes/responz/wp-content/themes/responz/themify/img/social/twitter.png";s:32:"setting-link_type_themify-link-2";s:10:"image-icon";s:33:"setting-link_title_themify-link-2";s:7:"Google+";s:32:"setting-link_link_themify-link-2";s:45:"https://plus.google.com/102333925087069536501";s:31:"setting-link_img_themify-link-2";s:99:"https://themify.me/demo/themes/responz/wp-content/themes/responz/themify/img/social/google-plus.png";s:32:"setting-link_type_themify-link-1";s:10:"image-icon";s:33:"setting-link_title_themify-link-1";s:8:"Facebook";s:32:"setting-link_link_themify-link-1";s:27:"http://facebook.com/themify";s:31:"setting-link_img_themify-link-1";s:96:"https://themify.me/demo/themes/responz/wp-content/themes/responz/themify/img/social/facebook.png";s:32:"setting-link_type_themify-link-3";s:10:"image-icon";s:33:"setting-link_title_themify-link-3";s:7:"YouTube";s:31:"setting-link_img_themify-link-3";s:95:"https://themify.me/demo/themes/responz/wp-content/themes/responz/themify/img/social/youtube.png";s:32:"setting-link_type_themify-link-4";s:10:"image-icon";s:33:"setting-link_title_themify-link-4";s:9:"Pinterest";s:31:"setting-link_img_themify-link-4";s:97:"https://themify.me/demo/themes/responz/wp-content/themes/responz/themify/img/social/pinterest.png";s:22:"setting-link_field_ids";s:171:"{"themify-link-0":"themify-link-0","themify-link-2":"themify-link-2","themify-link-1":"themify-link-1","themify-link-3":"themify-link-3","themify-link-4":"themify-link-4"}";s:23:"setting-link_field_hash";s:1:"5";s:30:"setting-page_builder_is_active";s:6:"enable";s:41:"setting-page_builder_animation_appearance";s:4:"none";s:42:"setting-page_builder_animation_parallax_bg";s:4:"none";s:46:"setting-page_builder_animation_parallax_scroll";s:6:"mobile";s:44:"setting-page_builder_animation_sticky_scroll";s:4:"none";s:4:"skin";s:82:"https://themify.me/demo/themes/responz/wp-content/themes/responz/skins/0/style.css";s:13:"import_images";s:2:"on";}<?php $themify_data = unserialize( ob_get_clean() );

	// fix the weird way "skin" is saved
	if( isset( $themify_data['skin'] ) ) {
		$parsed_skin = parse_url( $themify_data['skin'], PHP_URL_PATH );
		$basedir_skin = basename( dirname( $parsed_skin ) );
		$themify_data['skin'] = trailingslashit( get_template_directory_uri() ) . 'skins/' . $basedir_skin . '/style.css';
	}

	themify_set_data( $themify_data );
	
}
themify_do_demo_import();